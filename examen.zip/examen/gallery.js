const gallery = document.getElementById('gallery');
const prevPageBtn = document.getElementById('prevPage');
const nextPageBtn = document.getElementById('nextPage');
let currentPage = 1;
const perPage = 10;
const apiKey = 'iakPWtA7ESymzo8DK40u7cx0pTEaOa1b8MvlB8mka5i2uMRJsVBrIfox';

async function fetchImages(page) {
    const response = await fetch(`https://api.pexels.com/v1/curated?page=${page}&per_page=${perPage}`, {
        headers: {
            Authorization: apiKey
        }
    });
    const data = await response.json();
    return data.photos;
}

function displayImages(images) {
    gallery.innerHTML = images.map(image => `
        <div class="image">
            <img src="${image.src.medium}" alt="${image.alt}" />
        </div>
    `).join('');
}

async function loadPage(page) {
    const images = await fetchImages(page);
    displayImages(images);
    prevPageBtn.disabled = page === 1;
    nextPageBtn.disabled = images.length < perPage;
}

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        loadPage(currentPage);
    }
});

nextPageBtn.addEventListener('click', () => {
    currentPage++;
    loadPage(currentPage);
});

document.addEventListener('DOMContentLoaded', () => {
    loadPage(currentPage);
});
