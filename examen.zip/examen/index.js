document.addEventListener('DOMContentLoaded', function() {
    const email = localStorage.getItem('email');

    const authButtons = document.getElementById('authButtons');
    if (email) {
        authButtons.innerHTML = `
            <a class="nav-link active" href="#" id="logout">Вийти</a>
        `;

        document.getElementById('logout').addEventListener('click', function(event) {
            event.preventDefault();
            localStorage.clear();
            window.location.reload();
        });
    } else {
        authButtons.innerHTML = `
            <a class="nav-link active" href="login.html">Увійти</a>
            <a class="nav-link active" href="registration.html">Зареєструватися</a>
        `;
    }
});