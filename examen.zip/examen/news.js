const apiKey = 'dd73aaf2484e40caaf19bb4f3dd7279f';
        const pageSize = 10;
        let currentPage = 1;
        let totalResults = 0;

        document.addEventListener('DOMContentLoaded', () => {
            loadNews();
        });

        async function loadNews() {
            const url = `https://newsapi.org/v2/everything?q=tesla&sortBy=publishedAt&page=${currentPage}&pageSize=${pageSize}&apiKey=${apiKey}`;
            try {
                const response = await fetch(url);
                const data = await response.json();

                if (data.status === 'ok') {
                    displayNews(data.articles);
                    totalResults = data.totalResults;
                    updatePagination();
                } else {
                    console.error('Помилка у відповіді API:', data.message);
                }
            } catch (error) {
                console.error('Помилка запиту до API:', error);
            }
        }

        function displayNews(articles) {
            const container = document.getElementById('news-container');
            container.innerHTML = '';
            articles.forEach(article => {
                const newsItem = document.createElement('div');
                newsItem.classList.add('news-item');
                newsItem.innerHTML = `
                    <img src="${article.urlToImage}" alt="Зображення відсутнє">
                    <h2>${article.title}</h2>
                    <p>${article.description}</p>
                    <p><small>${new Date(article.publishedAt).toLocaleDateString()}</small></p>
                    <a href="${article.url}" target="_blank">Джерело</a>
                `;
                container.appendChild(newsItem);
            });
        }

        function updatePagination() {
            const pageInfo = document.getElementById('page-info');
            const totalPages = Math.ceil(totalResults / pageSize);
            pageInfo.textContent = `Сторінка ${currentPage} з ${totalPages}`;
            
            document.getElementById('prev').disabled = currentPage === 1;
            document.getElementById('next').disabled = currentPage === totalPages;
        }

        function nextPage() {
            if (currentPage < Math.ceil(totalResults / pageSize)) {
                currentPage++;
                loadNews();
            }
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                loadNews();
            }
        }