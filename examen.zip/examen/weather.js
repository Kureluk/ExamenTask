document.addEventListener('DOMContentLoaded', () => {
    const city = document.getElementById('City').value;
    const key = "9c8ba75b0a7544bf87d173654242904";
    const url = "http://api.weatherapi.com/v1/forecast.json";
    const requestUrl = `${url}?key=${key}&days=3&q=${city}`;
    weatherFetch(requestUrl);
});

document.getElementById('searchBtn').addEventListener('click', () => {
    const city = document.getElementById('City').value;
    const key = "9c8ba75b0a7544bf87d173654242904";
    const url = "http://api.weatherapi.com/v1/forecast.json";
    const requestUrl = `${url}?key=${key}&days=3&q=${city}`;
    weatherFetch(requestUrl);
});

const weatherFetch = async (requestUrl) => {
    try {
        const response = await fetch(requestUrl);
        const json = await response.json();
        console.log("json", json);
        forecastHandler(json.forecast);
        document.getElementById('CityName').innerHTML = json.location.name;
    } catch (error) {
        console.error(error);
    }
};

const forecastHandler = (forecast) => {
    const list = document.getElementById("weather");
    const uls = list.children;


    for (let i = 0; i < forecast.forecastday.length; i++) {
        const day = forecast.forecastday[i];
        console.log(day);
        
        uls[i].innerHTML = day.date;
        const hourList = document.createElement("ul");
        
        for (let j = 0; j < day.hour.length; j+=2) {
            const hour = day.hour[j];
            const temp = hour.temp_c;
            const wind = hour.wind_kph;
            const pressure = hour.pressure_mb;
            const hum = hour.humidity;
            let icon = `https:${hour.condition.icon}`;

            const li = document.createElement('li');
            const ic = document.createElement('img');
            ic.src = icon; 
            li.innerHTML = `${hour.time.split(" ")[1]}`;
            li.appendChild(ic);
            li.innerHTML = li.innerHTML + ` ${temp}&#x2103\n` + ` ${wind} km/h\n` + ` ${pressure} mb\n` + ` ${hum}%`;
            hourList.appendChild(li);
        }
        uls[i].appendChild(hourList);
    }
};
