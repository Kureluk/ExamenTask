document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    document.getElementById('emailError').textContent = '';
    document.getElementById('passwordError').textContent = '';
    document.getElementById('confirmPasswordError').textContent = '';

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    const emailPattern = /^[a-zA-Z0-9._-]{3,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        document.getElementById('emailError').textContent = 'Неправильний формат електронної пошти';
        return;
    }

    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,}$/;
    if (!passwordPattern.test(password)) {
        document.getElementById('passwordError').textContent = 'Пароль має містити мінімум 6 символів, включаючи 1 літеру нижнього регістра, 1 літеру верхнього регістра та 1 цифру';
        return;
    }

    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Паролі не збігаються';
        return;
    }

    localStorage.setItem('email', email);
    localStorage.setItem('password', password);

    document.location.href = "index.html";
});
