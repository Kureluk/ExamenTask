document.addEventListener('DOMContentLoaded', function() {
    const email = localStorage.getItem('email');
    const password = localStorage.getItem('password');

    if (email) {
        document.getElementById('login').value = email;
    }
    if (password) {
        document.getElementById('password').value = password;
    }
});


document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    email = localStorage.getItem('email');
    password = localStorage.getItem('password');

    const username = document.getElementById('login').value;
    const userPassword = document.getElementById('password').value;
    const message = document.getElementById('message');

    if (username === email && userPassword === password) {
        window.location.href = 'index.html';
    } else {
        message.textContent = 'Неправильний логін або пароль';
    }
});
